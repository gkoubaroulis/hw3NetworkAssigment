# tcp-client-server-in-C

See the explanation in this video: https://www.youtube.com/watch?v=hptViBE23fI

This is a simple TCP Client Server program in C language. 

[![Run on Repl.it](https://repl.it/badge/github/nikhilroxtomar/tcp-client-server-in-C)](https://repl.it/github/nikhilroxtomar/tcp-client-server-in-C)